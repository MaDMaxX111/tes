export default {
  responseTimeout: 10000,

  remote: {
    isEnabled: false, // флаг переключения между фиктивным и реальным сервером
    url: 'https://health-empire.com/app' // URL реального сервера
  }
}